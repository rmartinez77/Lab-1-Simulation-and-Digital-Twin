
### A - Block A should be at the beginning of your code
import sim
import time
import sys
import  ikpy
import  numpy  as  np
from  ikpy  import  plot_utils
#### End of A

#-----Try to connect---------------
sim.simxFinish(-1)
clientID = sim.simxStart('192.168.1.2',19999,True,True,10000,5)
if clientID != -1:
    print("Connected to remote API server")
else:
    print("Not connected to remote API server")
    sys.exit ("could not connect")
    
#-----Start the Paused Simulation
err_code = sim.simxStartSimulation(clientID,sim.simx_opmode_oneshot)


#-----Initialize Joint Handles---------
err_code,m1 = sim.simxGetObjectHandle(clientID,"m1",sim.simx_opmode_blocking)
err_code,m2 = sim.simxGetObjectHandle(clientID,"m2",sim.simx_opmode_blocking)
err_code,m3 = sim.simxGetObjectHandle(clientID,"m3",sim.simx_opmode_blocking)

### B Where do you think B block should go?
my_chain = ikpy.chain.Chain.from_urdf_file( "./resources/poppy_ergo.URDF" )

target_vector = [  0.1 , - 0.2 ,  0.1 ]
target_frame = np.eye( 4 )  # Homogeneous matrix [4x4] = [ 1 2 3]->(Rotation)[1x3]->position last row is  0 0 0 1
target_frame[: 3 ,  3 ] = target_vector
### End of B

### C Where do you think this part should go?
print ( "The angles of each joints are : " , my_chain.inverse_kinematics(target_frame))
the1, the2, the3, the4, the5, the6, the7 = my_chain.inverse_kinematics(target_frame)
### End of C

### D Where do you think C block should go?
# You need to add something similar to below:

pos_val = the1 # For the first joint
err_code = sim.simxSetJointTargetPosition (clientID, m1,pos_val,sim.simx_opmode_streaming) # set the postion of M1

pos_val = the2 # for the second joint
err_code = sim.simxSetJointTargetPosition (clientID, m2,pos_val,sim.simx_opmode_streaming) # set the postion of M2

pos_val = the3 # for the second joint
err_code = sim.simxSetJointTargetPosition (clientID, m3,pos_val,sim.simx_opmode_streaming) # set the postion of M3
### End of D

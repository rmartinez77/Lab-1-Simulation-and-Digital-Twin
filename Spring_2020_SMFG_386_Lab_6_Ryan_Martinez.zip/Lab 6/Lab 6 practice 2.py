import numpy as np
import sim
import sys
import time
import robopy.base.model as model


#-----Try to connect---------------
sim.simxFinish(-1)
clientID = sim.simxStart('192.168.1.2',19999,True,True,10000,5)
if clientID != -1:
    print("Connected to remote API server")
else:
    print("Not connected to remote API server")
    sys.exit ("could not connect")
    
#-----Start the Paused Simulation
err_code = sim.simxStartSimulation(clientID,sim.simx_opmode_oneshot)


#-----Initialize Joint Handles---------
err_code,j1 = sim.simxGetObjectHandle(clientID,"J1",sim.simx_opmode_blocking)
err_code,j2 = sim.simxGetObjectHandle(clientID,"J2",sim.simx_opmode_blocking)
err_code,j3 = sim.simxGetObjectHandle(clientID,"J3",sim.simx_opmode_blocking)

while True:
    print("hello world")
    a = np.transpose(np.asmatrix(np.linspace(1, -180, 500)))
    print ("a:")
    print (a)
    b = np.transpose(np.asmatrix(np.linspace(1, 180, 500)))
    print ("b:")
    print (b) 
    c = np.transpose(np.asmatrix(np.linspace(1, 90, 500)))
    print ("c:")
    print (c)
    d = np.transpose(np.asmatrix(np.linspace(1, 450, 500)))
    print ("d:")
    print (d)
    e = np.asmatrix(np.zeros((500, 1)))
    print ("e:")
    print (e)
    f = np.concatenate((d, b, a, e, c, d), axis=1)
    print ("f:")
    print (f)
    
    pos_val = a[1] # robot.animate(stances=f, frame_rate=30, unit='deg')  
    err_code = sim.simxSetJointTargetPosition (clientID, j1,pos_val,sim.simx_opmode_streaming) # set the postion of J1

    time.sleep(1) #wait a short amount of time

    pos_val = np.radians(10) # in degrees 0
    err_code = sim.simxSetJointTargetPosition (clientID, j2,pos_val,sim.simx_opmode_streaming) # set the postion of J2
    
    time.sleep(1) #wait a short amount of time

    pos_val = np.radians(30) # in degrees 0
    err_code = sim.simxSetJointTargetPosition (clientID, j3,pos_val,sim.simx_opmode_streaming) # set the postion of J3

    time.sleep(1)
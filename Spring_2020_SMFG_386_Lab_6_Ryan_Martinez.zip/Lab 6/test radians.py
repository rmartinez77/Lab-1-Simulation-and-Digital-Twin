import numpy

deg = numpy.radians(10)
print(deg)
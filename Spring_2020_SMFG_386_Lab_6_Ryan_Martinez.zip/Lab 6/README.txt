The Controls_proj.py file is what I have written. 

The “.ttt file is the vrep model

The other files are for the pythonvrep api. They are necessary.

To start the simulation and controller:
  -Import the vrep scene (Controls_Proj_REPE.ttt) into vrep
  -Start the simulation and immediatelly pause it before the pendulum falls
  -Begin the Python script (USING PYTHON 2.7!): "controls_proj.py"
